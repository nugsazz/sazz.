cordova.define("org.apache.cordova.speech.speechrecognition.SpeechRecognitionEvent", function(require, exports, module) {
var SpeechRecognitionEvent = function() {
    this.resultIndex;
    this.results;
    this.interpretation;
    this.emma;
};

module.exports = SpeechRecognitionEvent;

});
