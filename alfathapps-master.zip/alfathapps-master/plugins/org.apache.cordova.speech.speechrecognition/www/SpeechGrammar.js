var SpeechGrammar = function() {
    this.src;
    this.weight;
};

module.exports = SpeechGrammar;
