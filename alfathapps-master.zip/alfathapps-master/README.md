to Start server

server :
node server.js

client:
www/
